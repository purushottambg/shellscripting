#!/bin/bash

read -p 'Your good name please:' name

echo Namaste $name 
