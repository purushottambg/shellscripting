#!/bin/bash

echo "Welcome to the watch"
while true 
do
clear
echo $(date +%H:%m:%S)
sleep 1
done 